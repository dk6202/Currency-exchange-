// Populate currency dropdowns
const currencies = ["USD", "EUR", "INR", "GBP", "AUD", "CAD", "JPY"];
const fromSelect = document.getElementById("fromCurrency");
const toSelect = document.getElementById("toCurrency");

currencies.forEach(currency => {
  let option1 = new Option(currency, currency);
  let option2 = new Option(currency, currency);
  fromSelect.add(option1);
  toSelect.add(option2);
});

fromSelect.value = "USD";
toSelect.value = "INR";

// Conversion function
async function convertCurrency() {
  const amount = document.getElementById("amount").value;
  const from = fromSelect.value;
  const to = toSelect.value;

  if (!amount) {
    alert("Please enter an amount");
    return;
  }

  const url = `https://api.exchangerate.host/convert?from=${from}&to=${to}&amount=${amount}`;
  
  const res = await fetch(url);
  const data = await res.json();

  document.getElementById("result").innerText =
    `${amount} ${from} = ${data.result.toFixed(2)} ${to}`;
}
